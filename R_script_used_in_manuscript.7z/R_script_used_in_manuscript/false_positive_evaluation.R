# This is a framework to prove the ABC transformation will not
# introduce more false positive in t-test based on Monte Carlo simulation

# Normal distribution and four common beta distributions are tested.
# Their peak shape parameters are set as follows:
# type 5: alpha = 0.3, beta = 0.6
# type 6: alpha = 5, beta = 2
# type 7: alpha = 2, beta = 5
# type 8: alpha = 0.5, beta = 2

# Function to optimize lambda value
lambda_opt = function(data_seq, Group_vector, L1 = -3, L2 = 3){
  lambda_seq = seq(L1, L2, 0.01)
  note = "Transformed"
  p_new = c()
  p_seq = c()
  ds = c()
  counter = 1
  gn = length(Group_vector)
  # Separate data into groups
  for (i in 1:gn) {
    ds[[i]] = data_seq[counter:(counter+Group_vector[i]-1)]
    counter = counter + Group_vector[i]
  }
  
  for (i in 1:length(lambda_seq)) {
    p_values = c()
    if(lambda_seq[i] == 0){
      for (j in 1:gn) {
        p_values[j] = shapiro.test(log( ds[[j]] ))$p.value
      }
    } else{
      for (j in 1:gn) {
        lambda_test = lambda_seq[i]
        group_data = ( ds[[j]]^lambda_test - 1 ) / lambda_test
        p_values[j] = shapiro.test(group_data)$p.value
      }
    }
    p_seq[i] = prod(p_values)
  }
  
  for (i in 1:gn) {
    p_values[i] = shapiro.test( ds[[i]] )$p.value
  }
  
  p_seq = append(p_seq, prod(p_values))
  index = match(max(p_seq),p_seq)
  lambda_final = lambda_seq[index]
  
  if(is.na(lambda_final)){note = "Original"} else if(lambda_final == 0){data_seq = log(data_seq)} else{data_seq = (data_seq^lambda_final-1)/lambda_final}
  counter = 1
  for (i in 1:gn) {
    a = data_seq[counter:(counter+Group_vector[i]-1)]
    counter = counter + Group_vector[i]
    p_new[i] = shapiro.test(a)$p.value
  }
  
  
  result = list("data_trans" = data_seq, 
                "lambda" = lambda_final,
                "note" = note,
                "p_old" = p_seq[length(p_seq)],
                "p_new" = max(p_seq),
                "p_old_all" = p_values,
                "p_new_all" = p_new)
  
  return(result)
}

dtype = matrix(c(0.3, 0.6, 5, 2, 2, 5, 0.5, 2), nrow = 4, byrow = T)
sample_size = 30
rep_times = 10000

p_table = data.frame(matrix(2, nrow = rep_times, ncol = 10))
colnames(p_table) = c('type5', 'type5_ABC', 'type6', 'type6_ABC', 'type7', 'type7_ABC',
                      'type8', 'type8_ABC', 'normal', 'normal_ABC')

# Evaluation of 4 beta distributions
for (i in 1:4) {
  alpha = dtype[i,1]
  beta = dtype[i,2]
  pb <- txtProgressBar(min = 0, max = rep_times, style = 3)
  
  for (j in 1:rep_times) {
    data1 = rbeta(sample_size, dtype[i,1], dtype[i,2])*1000 + 1
    data2 = rbeta(sample_size, dtype[i,1], dtype[i,2])*1000 + 1
    p_table[j, i*2-1] = t.test(data1, data2)$p.value
    temp = lambda_opt(c(data1, data2), Group_vector = c(sample_size,sample_size))$data_trans
    p_table[j, i*2] = t.test(temp[1:sample_size],temp[(sample_size+1):(2*sample_size)])$p.value
    setTxtProgressBar(pb, j)
  }
  close(pb)
  print('------------------------------------------')
}


# Evaluation of 1 normal distribution
for (j in 1:rep_times) {
  data1 = rnorm(sample_size, 1000, 100)
  data2 = rnorm(sample_size, 1000, 100)
  p_table[j, 5*2-1] = t.test(data1, data2)$p.value
  temp = lambda_opt(c(data1, data2), Group_vector = c(sample_size,sample_size))$data_trans
  p_table[j, 5*2] = t.test(temp[1:sample_size],temp[(sample_size+1):(2*sample_size)])$p.value
  setTxtProgressBar(pb, j)
}

sig_level = 0.1
sigrate = c()
for (i in 1:ncol(p_table)) {
  sigrate[i] = sum(p_table[,i] < sig_level) / rep_times
}

